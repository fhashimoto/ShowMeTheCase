export default {
  rows: [
    // 1. Row
    [
      {
        key: "First Name",
        value: "Jan"
      },
      {
        key: "Mobile",
        value: "+61499029429"
      },
      {
        key: "Survey",
        value: "Postop"
      }
    ],
    // 2. Row
    [
      {
        key: "First Name",
        value: "Peter"
      },
      {
        key: "Mobile",
        value: "+61499323429"
      },
      {
        key: "Survey",
        value: "Postop"
      }
    ]
  ]
};
