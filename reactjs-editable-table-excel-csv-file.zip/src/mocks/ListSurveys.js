export default [
  // {
  //   id: Math.random(),
  //   name: "Patient experience (pain medicine practice) - survey"
  // },
  {
    id: Math.random(),
    name: "Post Op"
  }
];
